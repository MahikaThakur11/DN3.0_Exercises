package com.code.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginDTO {
	
	    private String email;
	    
	    private String password;
	    
	    // getters and setters here...
	}

