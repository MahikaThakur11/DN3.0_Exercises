package com.library.repository;

public class BookRepository {
    public void getbook(){
        System.out.println("Books");
    }
}
